$(function () {
    document.write("1 - DOM еще не загружен; " + " ")
});

//document.addEventListener('DOMContentLoaded', (event) => {
//    document.write("2 - DOM уже загружен; " + " ")
//});

$(function () {
    document.write("3 - DOM уже загружен и функция вызвана после")
})

function doSomething() {
    console.info('DOM загружен');
  }
  
  if (document.readyState === 'loading') {  // Загрузка ещё не закончилась
    document.addEventListener('DOMContentLoaded', doSomething);
  } else {  // `DOMContentLoaded` Уже сработал
    doSomething();
  }
 